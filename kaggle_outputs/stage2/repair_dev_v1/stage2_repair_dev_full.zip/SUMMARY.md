# 3B repair development comparison

Repair-only synthetic development; not full Stage 2 or an independent benchmark.
Model quality run: True

- control: 11 correct, 1 incorrect accepted, 5 withheld; 39194 tokens.
- evidence: 15 correct, 1 incorrect accepted, 1 withheld; 27434 tokens.
- schema_guard: 12 correct, 0 incorrect accepted, 5 withheld; 40354 tokens.
- combined: 16 correct, 0 incorrect accepted, 1 withheld; 28976 tokens.
