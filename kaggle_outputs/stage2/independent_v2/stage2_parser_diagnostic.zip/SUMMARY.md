# Parser development diagnostic

Reference pass measures false rejection, not complete contract correctness. The wrong no-op probe covers only one error type. No automatic winner or Stage 2 accuracy is claimed.

- original_nf4: 16/20 reference passes; 20 schema-valid; 0/20 wrong no-ops accepted.
- profile_nf4: 8/20 reference passes; 19 schema-valid; 0/20 wrong no-ops accepted.
- original_fp16: 15/20 reference passes; 20 schema-valid; 0/20 wrong no-ops accepted.
- profile_fp16: 7/20 reference passes; 18 schema-valid; 1/20 wrong no-ops accepted.
